﻿using System;
using System.Collections.Generic;
using System.Text;

namespace appInventario.Services
{
    public interface iFileHelper
    {
        string obtenerRutaLocal(string sArchivo);
    }
}
