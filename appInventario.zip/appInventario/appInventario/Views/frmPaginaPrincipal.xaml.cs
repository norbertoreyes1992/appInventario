﻿using appInventario.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace appInventario.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class frmPaginaPrincipal : ContentPage
    {
        public paginaPrincipalViewModel vmMainPage { get; set; }
        public frmPaginaPrincipal()
        {
            InitializeComponent();
            vmMainPage = new paginaPrincipalViewModel();
            BindingContext = vmMainPage;
        }
    }
}