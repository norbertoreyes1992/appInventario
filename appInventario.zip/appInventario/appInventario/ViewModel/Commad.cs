﻿namespace appInventario.ViewModel
{
    public class Commad
    {
    }
}