﻿using appInventario.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace appInventario.ViewModel
{
    public class agregarArticulosViewModel: BaseViewModel
    {        
        public articuloModel _mArticulo { get; set; }
        public Command agregarArticulo { get; set; }
        public articuloModel mArticulo
        {
            get => _mArticulo;
            set
            {
                _mArticulo = value;
                OnPropertyChanged();
            }
        }

        public agregarArticulosViewModel()
        {
            agregarArticulo = new Command(async () => await guardarArticulo());
            mArticulo = new articuloModel();
        }

        private async Task guardarArticulo()
        {
            await App.dbBase.guardarArticulo(mArticulo);
            await Application.Current.MainPage.DisplayAlert("Información", "Datos Guardados Con Exito", "Ok");
            mArticulo = new articuloModel();
            paginaPrincipalViewModel vm = new paginaPrincipalViewModel();
            vm.obtenerArticulos();
        }

    }
}
