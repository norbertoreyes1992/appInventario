﻿using appInventario.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace appInventario.ViewModel
{
    public class paginaPrincipalViewModel: BaseViewModel
    {
        public Command refresarArticulos { get; set; }

        private ObservableCollection<articuloModel> _listaAmigos;

        public ObservableCollection<articuloModel> listaAmigos
        {
            get => _listaAmigos;
            set
            {
                _listaAmigos = value;
                OnPropertyChanged();
            }
        }

        public paginaPrincipalViewModel()
        {
            obtenerArticulos();
            refresarArticulos = new Command(obtenerArticulos);
        }

        public async void obtenerArticulos()
        {
            IsBusy = true;

            var respuesta = await App.dbBase.obtenerArticulos();
            listaAmigos = new ObservableCollection<articuloModel>(respuesta);

            //Task.Run(async () => listaAmigos = await App.dbBase.obtenerArticulos()).Wait();
            IsBusy = false;
        }

    }
}
